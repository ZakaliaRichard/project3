import React, { Component } from 'react';    
import Preposition from './components/Preposition';
class App extends Component {
  render() {
    return (
        <Preposition />
    );
  }
}

export default App;
